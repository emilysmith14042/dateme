---
layout: news_item
title: 'Alfred Xing has joined the Jekyll core team'
date: 2014-12-17 11:16:21 -0800
author: parkr
version: alfredxing
categories: [team]
---

We're excited to announce that [@alfredxing][] has joined the @jekyll/core
team!

He hails from Vancouver, BC, Canada, where he is studying Economics and
Computer Science at the [University of British Columbia][]. Alfred popped up in
the issues a few months ago with terrific insights, focus, and humility.
Performance buffs may be pleased to hear incremental regeneration will be
released in a future version of Jekyll -- a significant piece of the
feature written by Alfred.

Please join me in welcoming Alfred to the Jekyll core team. We're excited
he's agreed to lend his talents to this project. The future is an exciting
place!

Happy Jekylling!

[@alfredxing]: https://github.com/alfredxing
[University of British Columbia]: http://ubc.ca
