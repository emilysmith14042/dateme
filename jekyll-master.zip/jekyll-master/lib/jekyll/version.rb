module Jekyll
  VERSION = "3.2.1".freeze
end
